package com.cg.emp.service;

import java.util.List;

import com.cg.emp.dtos.EmployeeBean;

public interface IEmployeeService {

	void addEmployee(EmployeeBean bean);

	EmployeeBean getEmployee(int eid);

	List<EmployeeBean> getAll();

	List<Integer> getIds();

	boolean delete(int empId);

	void updateEmployee(EmployeeBean bean);



}
