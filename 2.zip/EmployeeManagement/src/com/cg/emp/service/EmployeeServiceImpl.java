package com.cg.emp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.emp.dao.IEmployeeDao;
import com.cg.emp.dtos.EmployeeBean;


@Service
public class EmployeeServiceImpl implements IEmployeeService
{
	
	@Autowired
	private IEmployeeDao dao; 

	@Override
	public void addEmployee(EmployeeBean bean) {
		
		dao.addEmployee(bean);
	}

	@Override
	public EmployeeBean getEmployee(int eid) {
		
		return dao.getEmployee(eid);
	}

	@Override
	public List<EmployeeBean> getAll() {
		
		return dao.getAll();
	}

	@Override
	public List<Integer> getIds() {
	
		return dao.getIds();
	}

	@Override
	public boolean delete(int empId) {
		
		
		return dao.delete(empId);
	}

	@Override
	public void updateEmployee(EmployeeBean bean) {
		dao.updateEmployee( bean);
	}

}
