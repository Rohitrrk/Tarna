package com.cg.emp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.emp.dtos.EmployeeBean;


@Repository
@Transactional
public class EmployeeDaoImpl implements IEmployeeDao
{
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public void addEmployee(EmployeeBean bean) {
		entityManager.persist(bean);
		entityManager.flush();
		
	}

	@Override
	public EmployeeBean getEmployee(int eid) {
		EmployeeBean bean = new EmployeeBean();
		bean=entityManager.find(EmployeeBean.class, eid);
		return bean;
	}

	@Override
	public List<EmployeeBean> getAll() {
	
		/*
		TypedQuery<EmployeeBean> query = entityManager.createQuery("Select e From EmployeeBean e", EmployeeBean.class);
		return query.getResultList();*/
		
		Query q = entityManager.createNamedQuery("getAll");
		return q.getResultList();
		
	}

	@Override
	public List<Integer> getIds() {

		/*TypedQuery<Integer> query = entityManager.createQuery("Select empId From EmployeeBean e", Integer.class);
		return query.getResultList();*/
		Query q = entityManager.createNamedQuery("getId");
		return q.getResultList();

	}

	@Override
	public boolean delete(int empId) {
		
		EmployeeBean bean =  getEmployee(empId);
		entityManager.remove(bean);
		return true;
	}

	@Override
	public void updateEmployee(EmployeeBean bean) {
		entityManager.merge(bean);
		entityManager.flush();
		
	}

}
