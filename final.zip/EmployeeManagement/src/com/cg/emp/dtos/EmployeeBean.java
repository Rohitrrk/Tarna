package com.cg.emp.dtos;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="employee_table")
@NamedQueries({
		
		@NamedQuery(name="getAll" ,query="Select e From EmployeeBean e"),
		@NamedQuery(name="getId" ,query="Select empId From EmployeeBean e"),
		@NamedQuery(name="delId", query="delete from EmployeeBean emp where emp.empId= :empId")
		
})
public class EmployeeBean {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int empId;
	
	@NotEmpty(message="Employee Name is Mandatory")
	@Size(min = 2,message="Name should have atleast 2 character")
	private String empName;
	
	@NotNull(message="Employee PhoneNo is Mandatory")
	private long empPhoneNo;
	
	@NotNull(message="Salary Required")
	private int salary;
	
	@NotEmpty(message="Employee designation is Mandatory")
	private String designation;
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public long getEmpPhoneNo() {
		return empPhoneNo;
	}
	public void setEmpPhoneNo(long empPhoneNo) {
		this.empPhoneNo = empPhoneNo;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	@Override
	public String toString() {
		return "EmployeeBean [empId=" + empId + ", empName=" + empName
				+ ", empPhoneNo=" + empPhoneNo + ", salary=" + salary
				+ ", designation=" + designation + "]";
	}
	
	
	
	
	

}
