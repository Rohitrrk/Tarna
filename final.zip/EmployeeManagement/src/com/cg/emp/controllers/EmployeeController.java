package com.cg.emp.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;






import com.cg.emp.dtos.EmployeeBean;
import com.cg.emp.service.IEmployeeService;


@Controller
public class EmployeeController {
	
	@Autowired
	private IEmployeeService service;
	
	@RequestMapping("/welcome")
	public String showFirstPage()
	{
		return "index";
		
	}
	
	@RequestMapping("/register")
	public String showRegFrom(Model model)
	{
		model.addAttribute("employee", new EmployeeBean());
		return "EmployeeRegForm";
	}
	
	@RequestMapping("/addEmployee")
	public ModelAndView addEmployee(@ModelAttribute("employee") @Valid EmployeeBean bean,BindingResult result)
	{
		if(result.hasErrors())
		{
			return new ModelAndView("EmployeeRegForm","employee",new EmployeeBean());
		}
		else
		{
		service.addEmployee(bean);
		return new ModelAndView("regSuccess","emp",bean);
		}
	}
	
	@RequestMapping("/getById")
	public ModelAndView showgetByIdPage(Model model)
	{
		List<Integer> ids = service.getIds();
		model.addAttribute("employee", new EmployeeBean());
		return new ModelAndView("getByIdPage","id",ids);
		
	}
	
	
	
	@RequestMapping("/getDetails")
	public ModelAndView getEmployee(@RequestParam("empId") String id)
	{
		EmployeeBean bean = new EmployeeBean();
		int eid= Integer.parseInt(id);
		bean = service.getEmployee(eid);
		return new ModelAndView("showData","emp",bean);
		
	}
	
	@RequestMapping("/getAll")
	public ModelAndView getAllDetails()
	{
		List<EmployeeBean> allist = service.getAll();
		return new ModelAndView("DisplayAll","list",allist);
	}

	
	@RequestMapping("/delete")
	public String deleteEmployee(@RequestParam int empId,EmployeeBean bean)
	{
		if(service.delete(empId))
		{
			System.out.println("Data Deleted Successfully");
		}
			else
				System.out.println("Not Deleted");
			
			return "redirect:getAll.obj";
			
	
	}
	
	@RequestMapping("/edit")
	public String showUpdateRegFrom(@RequestParam("empId") int empId, Model model)
	{
		EmployeeBean emp = service.getEmployee(empId);
		
		
		model.addAttribute("employee", emp);
		return "UpdateEmployeeRegForm";
	}
	
	@RequestMapping("/updateEmployee")
	public String updateEmployee(@ModelAttribute("employee") @Valid EmployeeBean bean,BindingResult result)
	{
		/*if(result.hasErrors())
		{
			return new ModelAndView("UpdateEmployeeRegForm","employee",bean);
		}*/
		service.updateEmployee(bean);
		
		return "redirect:getAll.obj";
		
		
	}
}
