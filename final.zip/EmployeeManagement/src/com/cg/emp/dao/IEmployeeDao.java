package com.cg.emp.dao;

import java.util.List;

import com.cg.emp.dtos.EmployeeBean;

public interface IEmployeeDao {

	void addEmployee(EmployeeBean bean);

	EmployeeBean getEmployee(int eid);

	List<EmployeeBean> getAll();

	List<Integer> getIds();

	boolean delete(int empId);
	

	void updateEmployee(EmployeeBean bean);

}
